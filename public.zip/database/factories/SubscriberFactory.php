<?php

use App\Models\Subscriber;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Hash;

$factory->define(Subscriber::class, function (Faker $faker) {

    return [
        'name' => $faker->firstName . ' ' . $faker->lastName,
        'email' => 'abc' . rand(1, 100) . '@gmail.com',
        'password' => Hash::make('123'),
        'address' => $faker->address,
        'mobile' => '01750840217',
        'remember_token' => Str::random(10),
    ];
});