<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Supply;
use Faker\Generator as Faker;

$factory->define(Supply::class, function (Faker $faker) {
    return [
        //
    ];
});
