<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Poster;
use Faker\Generator as Faker;

$factory->define(Poster::class, function (Faker $faker) {
    return [
        //
    ];
});
