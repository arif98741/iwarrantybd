 <?php $__env->startSection('title','Report Dashboard'); ?> <?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2 class="page-header">Report Dashboard</h2>
    </div>
</div>
<div class="row">
    <?php if(Session::has('success')): ?>
    <p class="alert alert-success message"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?> <?php if(Session::has('error')): ?>
    <p class="alert alert-warning message"><?php echo e(Session::get('error')); ?></p>
    <?php endif; ?>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_claim); ?></div>
                        <div>Claims</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(url('admin/report/claim')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">Get Report</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($completed_claim); ?></div>
                        <div>Completed Claims</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(url('admin/claim/1')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_subscriber); ?></div>
                        <div>Total Subscriber</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('admin.subscriber.index')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-university fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_center); ?></div>
                        <div>Total Center</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

</div>
<div class="row">
    <?php if(Session::has('success')): ?>
    <p class="alert alert-success message"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?> <?php if(Session::has('error')): ?>
    <p class="alert alert-warning message"><?php echo e(Session::get('error')); ?></p>
    <?php endif; ?>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_claim); ?></div>
                        <div>Pending Claims</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(url('admin/claim/0')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($completed_claim); ?></div>
                        <div>Completed Claims</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(url('admin/claim/1')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_subscriber); ?></div>
                        <div>Total Subscriber</div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('admin.subscriber.index')); ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-university fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?php echo e($total_center); ?></div>
                        <div>Total Center</div>
                    </div>
                </div>
            </div>
            <a href="#">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iwarranty1\resources\views/admin/report/index.blade.php ENDPATH**/ ?>