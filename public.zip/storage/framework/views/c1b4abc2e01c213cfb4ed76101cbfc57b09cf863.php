 <?php $__env->startSection('title','Setting'); ?> <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Setting</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Setting</a></li>

                        <li class="breadcrumb-item active">Setting</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <div class="content">

        <div class="row">
            <div class="col-md-6">
                <div class="card card-primary">
                    <div class="card-body">
                        <form role="form" action="<?php echo e(route('admin.setting')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact</label>
                                <input type="text" name="contact" value="<?php echo e($setting->contact); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Address</label>
                                <input type="text" name="address" value="<?php echo e($setting->address); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="text" name="email" value="<?php echo e($setting->email); ?>" class="form-control">
                            </div>
                    </div>

                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-primary">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Facebook</label>
                            <input type="text" name="facebook" value="<?php echo e($setting->facebook); ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Twitter</label>
                            <input type="text" name="twitter" value="<?php echo e($setting->twitter); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Pinterest</label>
                            <input type="text" name="pinterest" value="<?php echo e($setting->pinterest); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Instragram</label>
                            <input type="text" name="instagram" value="<?php echo e($setting->instagram); ?>" class="form-control">
                        </div>

                    </div>

                </div>
            </div>

            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Update</button>


            </div>
            </form>

        </div>


    </div>

</div>
<?php $__env->startPush('extra-scripts'); ?>
<!-- <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>

<script>
    CKEDITOR.replace('description');
</script> -->
<?php $__env->stopPush(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iwarranty1\resources\views/admin/setting.blade.php ENDPATH**/ ?>