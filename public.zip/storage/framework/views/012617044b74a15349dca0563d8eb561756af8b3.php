 <?php $__env->startSection('title','Update Center'); ?> <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Update Center</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.center.index')); ?>">Center list</a></li>

                        <li class="breadcrumb-item active">Update Center</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Update Center</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form role="form" action="<?php echo e(route('admin.center.update',$center->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter name</label>
                            <input type="text" name="name" value="<?php echo e($center->name); ?>" class="form-control">
                        </div>




                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter mobile</label>
                            <input type="text" name="phone" value="<?php echo e($center->phone); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="text" name="email" value="<?php echo e($center->email); ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter address</label>
                            <input type="text" name="location" value="<?php echo e($center->location); ?>" class="form-control">
                        </div>




                    </div>

                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
            <!-- /.card -->

            <!-- Form Element sizes -->


        </div>
        <!-- /.card-body -->
</div>
<!-- /.card -->
<!-- Horizontal Form -->

<!-- /.card -->

</div>
</section>

<!-- /.content -->
</div>
<?php $__env->startPush('extra-scripts'); ?>
<script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>

<script>
    CKEDITOR.replace('description');
</script>
<?php $__env->stopPush(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iwarranty1\resources\views/admin/center/edit.blade.php ENDPATH**/ ?>