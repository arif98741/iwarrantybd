 <?php $__env->startSection('title','Add Vendor'); ?> <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add Vendor</h2>
        </div>
    </div>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <?php if(Session::has('success')): ?>
        <p class="alert alert-success" id="message"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?> <?php if(Session::has('error')): ?>
        <p class="alert alert-warning" id="message"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>

        <div class="container-fluid">
            <div class="row mb-1">
                <div class="col-sm-7">

                </div>
                <div class="col-sm-5">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>" style="color: #000 !important;">Home</a></li>
                        <li class="breadcrumb-item">Add Vendor</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add Vendor</h3>
                </div>

                <form role="form" action="<?php echo e(route('admin.vendor.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('POST'); ?> <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                        </div>


                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="type" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                        </div>


                        <div class="form-group">
                            <label for="exampleInputEmail1">Mobile</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Location</label>
                            <input type="text" name="location" class="form-control" value="<?php echo e(old('location')); ?>" required>
                        </div>

                        <!-- <div class="form-group">]
          <label for="exampleInputEmail1">Image</label>
          <input type="file" name="image" class="form-control"  >
        </div> -->
                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>


            </div>
            <!-- /.card -->

            <!-- Form Element sizes --

        </div>
        <!-- /.card-body -->
        </div>
        <!-- /.card -->


        <!-- /.card -->

</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iwarranty1\resources\views/admin/vendor/create.blade.php ENDPATH**/ ?>