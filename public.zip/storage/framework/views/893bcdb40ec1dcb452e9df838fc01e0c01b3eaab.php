 <?php $__env->startSection('title','Update Vendor'); ?> <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Vendor</h2>
        </div>
    </div>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <?php if(Session::has('success')): ?>
        <p class="alert alert-success message"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?> <?php if(Session::has('error')): ?>
        <p class="alert alert-warning message"><?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>

        <div class="container-fluid">
            <div class="row mb-1">
                <div class="col-sm-7">

                </div>
                <div class="col-sm-5">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>" style="color: #000 !important;">Home</a></li>
                        <li class="breadcrumb-item">Update Vendor</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <section class="content" style="min-height: 500px;">
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Update Vendor</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form role="form" action="<?php echo e(route('admin.vendor.update',$vendor->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?> <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter Name</label>
                            <input type="text" name="name" value="<?php echo e($vendor->name); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="text" name="email" value="<?php echo e($vendor->email); ?>" readonly class="form-control">
                        </div>


                        <div class="form-group">
                            <label for="exampleInputEmail1">Mobile</label>
                            <input type="text" name="phone" value="<?php echo e($vendor->phone); ?>" class="form-control">
                        </div>


                        <div class="form-group">
                            <label for="exampleInputEmail1">Location</label>
                            <input type="text" name="location" value="<?php echo e($vendor->location); ?>" class="form-control">
                        </div>


                        <!-- <div class="form-group">
                            <label for="exampleInputEmail1">Image</label>
                            <input type="file" name="image" value="" class="form-control">
                        </div>
 -->

                    </div>


                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>

        </div>

</div>

</div>
</section>
<!-- /.content -->
</div>
<?php $__env->startPush('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('asset/back/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>"> <?php $__env->stopPush(); ?> <?php $__env->startPush('extra-scripts'); ?>
<script src="<?php echo e(asset('asset/back/plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('asset/back/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
<script>
    $(function() {
        $("#example1").DataTable();
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
        });
    });
</script>
<?php $__env->stopPush(); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iwarranty1\resources\views/admin/vendor/edit.blade.php ENDPATH**/ ?>