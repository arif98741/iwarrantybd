<header>
    <div id="topbar" class="hide-s hide-m">
        <div class="line">
            <div class="m-6 l-6 hide-s">
                <p>CONTACT US: <strong>01750-840217</strong> | <strong>contact@sampledomain.com</strong></p>
            </div>
            <div class="s-12 m-6 l-6">
                <div class="social right">
                    <a><i class="icon-facebook_circle"></i></a> <a><i class="icon-twitter_circle"></i></a> <a><i
                            class="icon-google_plus_circle"></i></a> <a><i class="icon-instagram_circle"></i></a>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="line">
            <div class="s-12 l-2">
                <p class="logo"><strong>One</strong>page</p>
            </div>
            <div class="top-nav s-12 l-10">

                <ul class="right">
                    <li class="active-item"><a href="/">Home</a></li>
                    <li><a href="features">Features</a></li>
                    <li><a href="about-us">About Us</a></li>
                    <li><a href="our-work">Our Work</a></li>
                    <li><a href="services">Services</a></li>
                    <li><a href="contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>