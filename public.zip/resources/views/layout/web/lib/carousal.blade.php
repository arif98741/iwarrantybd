<div id="carousel">
    <div id="owl-demo" class="owl-carousel owl-theme">
        <div class="item">
            <img src="{{asset('asset/front/img/first.jpg')}}" alt="">
            <div class="line">
                <div class="text hide-s">
                    <div class="line">
                        <div class="prev-arrow hide-s hide-m">
                            <i class="icon-chevron_left"></i>
                        </div>
                        <div class="next-arrow hide-s hide-m">
                            <i class="icon-chevron_right"></i>
                        </div>
                    </div>
                    <h2>Free Onepage Responsive Template</h2>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
                </div>
            </div>
        </div>
        <div class="item">
            <img src="{{asset('asset/front/img/second.jpg')}}" alt="">
            <div class="line">
                <div class="text hide-s">
                    <div class="line">
                        <div class="prev-arrow hide-s hide-m">
                            <i class="icon-chevron_left"></i>
                        </div>
                        <div class="next-arrow hide-s hide-m">
                            <i class="icon-chevron_right"></i>
                        </div>
                    </div>
                    <h2>Fully Responsive Components</h2>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
                </div>
            </div>
        </div>
        <div class="item">
            <img src="{{asset('asset/front/img/third.jpg')}}" alt="">
            <div class="line">
                <div class="text hide-s">
                    <div class="line">
                        <div class="prev-arrow hide-s hide-m">
                            <i class="icon-chevron_left"></i>
                        </div>
                        <div class="next-arrow hide-s hide-m">
                            <i class="icon-chevron_right"></i>
                        </div>
                    </div>
                    <h2>Build new Layout in 10 minutes!</h2>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
                </div>
            </div>
        </div>
    </div>
</div>