<footer>
    <div class="line">
        <div class="s-12 l-6">
            <p>Copyright 2019, Vision Design - graphic zoo</p>
            <p>All images have been purchased from Bigstock. Do not use the images in your website.</p>
        </div>
        <div class="s-12 l-6">
            <a class="right" target="_blank" href="https://www.facebook.com/arifulislammmc007" title="Click to see profile">Developed<br> by Ariful Islam</a>
        </div>
    </div>
</footer>