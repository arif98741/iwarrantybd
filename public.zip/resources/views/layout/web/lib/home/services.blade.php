<div id="services">
    <div class="line">
        <h2 class="section-title">What we do</h2>
        <div class="margin">
            <div class="s-12 m-6 l-4 margin-bottom">
                <i class="icon-vector"></i>
                <div class="service-text">
                    <h3>We create</h3>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                </div>
            </div>
            <div class="s-12 m-6 l-4 margin-bottom">
                <i class="icon-eye"></i>
                <div class="service-text">
                    <h3>We look to the future</h3>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                </div>
            </div>
            <div class="s-12 m-12 l-4 margin-bottom">
                <i class="icon-random"></i>
                <div class="service-text">
                    <h3>We find a solution</h3>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                </div>
            </div>
        </div>
    </div>
</div>