<div id="our-work">
    <div class="line">
        <h2 class="section-title">Our Work</h2>
        <div class="tabs">
            <div class="tab-item tab-active">
                <a class="tab-label active-btn">Web Design</a>
                <div class="tab-content">
                    <div class="margin">
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por1.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por4.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por6.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por3.jpg')}}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-item">
                <a class="tab-label">Development</a>
                <div class="tab-content">
                    <div class="margin">
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por7.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por5.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por1.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por2.jpg')}}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-item">
                <a class="tab-label">Social Campaigns</a>
                <div class="tab-content">
                    <div class="margin">
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por4.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por6.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por3.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por5.jpg')}}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-item">
                <a class="tab-label">Photography</a>
                <div class="tab-content">
                    <div class="margin">
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por7.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por2.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por5.jpg')}}" alt="">
                            </a>
                        </div>
                        <div class="s-12 m-6 l-3">
                            <a class="our-work-container lightbox margin-bottom">
                                <div class="our-work-text">
                                    <h4>Lorem Ipsum Dolor</h4>
                                    <p>Laoreet dolore magna aliquam erat volutpat.</p>
                                </div><img src="{{asset('asset/front/img/por6.jpg')}}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>